/*
 *	MCreator note:
 *
 *	If you lock base mod element files, you can edit this file and the proxy files
 *	and they won't get overwritten. If you change your mod package or modid, you
 *	need to apply these changes to this file MANUALLY.
 *
 *
 *	If you do not lock base mod element files in Workspace settings, this file
 *	will be REGENERATED on each build.
 *
 */
package net.purymusic;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import net.purymusic.init.PuryMusicModSounds;
import net.purymusic.init.PuryMusicModItems;
import net.purymusic.init.PuryMusicModFeatures;

import net.minecraft.nbt.CompoundTag;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.api.ModInitializer;

public class PuryMusicMod implements ModInitializer {
	public static final Logger LOGGER = LogManager.getLogger();
	public static final String MODID = "pury_music";

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing PuryMusicMod");

		PuryMusicModItems.load();

		PuryMusicModFeatures.load();

		PuryMusicModSounds.load();

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			if (handler.getPlayer().getExtraCustomData().getCompound("PlayerPersisted").isEmpty()) {
				handler.getPlayer().getExtraCustomData().put("PlayerPersisted", new CompoundTag());
			}
			PuryMusicMod.LOGGER.info(handler.getPlayer().getExtraCustomData());
		});
	}
}
