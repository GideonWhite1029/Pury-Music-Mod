
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.purymusic.init;

import net.purymusic.item.Za4arHellsingItem;
import net.purymusic.item.YPIEQwQItem;
import net.purymusic.item.VirtualWorldItem;
import net.purymusic.item.VeberwowutuvebaangItem;
import net.purymusic.item.VeberFearItem;
import net.purymusic.item.VeberBeaItem;
import net.purymusic.item.SwergsBornToFlyItem;
import net.purymusic.item.ShapeOfVoiceItem;
import net.purymusic.item.SeimoroTakedaItem;
import net.purymusic.item.RXLZQUGLYItem;
import net.purymusic.item.RXLZQMyfavoritenameItem;
import net.purymusic.item.RXLZQBreathOfFireItem;
import net.purymusic.item.MxnarchNightwingItem;
import net.purymusic.item.MVTRIIIXSkinnyLifeItem;
import net.purymusic.item.MVTRIIIXAuroraItem;
import net.purymusic.PuryMusicMod;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

public class PuryMusicModItems {
	public static Item MVTRIIIX_AURORA;
	public static Item MXNARCH_NIGHTWING;
	public static Item VEBER_BEA;
	public static Item RXLZQUGLY;
	public static Item SEIMORO_TAKEDA;
	public static Item VEBERWOWUTUVEBAANG;
	public static Item YPIE_QW_Q;
	public static Item VIRTUAL_WORLD;
	public static Item SHAPE_OF_VOICE;
	public static Item SWERGS_BORN_TO_FLY;
	public static Item MVTRIIIX_SKINNY_LIFE;
	public static Item VEBER_FEAR;
	public static Item RXLZQ_BREATH_OF_FIRE;
	public static Item RXLZQ_MYFAVORITENAME;
	public static Item ZA_4AR_HELLSING;

	public static void load() {
		MVTRIIIX_AURORA = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "mvtriiix_aurora"), new MVTRIIIXAuroraItem());
		MXNARCH_NIGHTWING = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "mxnarch_nightwing"),
				new MxnarchNightwingItem());
		VEBER_BEA = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "veber_bea"), new VeberBeaItem());
		RXLZQUGLY = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "rxlzqugly"), new RXLZQUGLYItem());
		SEIMORO_TAKEDA = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "seimoro_takeda"), new SeimoroTakedaItem());
		VEBERWOWUTUVEBAANG = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "veberwowutuvebaang"),
				new VeberwowutuvebaangItem());
		YPIE_QW_Q = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "ypie_qw_q"), new YPIEQwQItem());
		VIRTUAL_WORLD = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "virtual_world"), new VirtualWorldItem());
		SHAPE_OF_VOICE = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "shape_of_voice"), new ShapeOfVoiceItem());
		SWERGS_BORN_TO_FLY = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "swergs_born_to_fly"),
				new SwergsBornToFlyItem());
		MVTRIIIX_SKINNY_LIFE = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "mvtriiix_skinny_life"),
				new MVTRIIIXSkinnyLifeItem());
		VEBER_FEAR = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "veber_fear"), new VeberFearItem());
		RXLZQ_BREATH_OF_FIRE = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "rxlzq_breath_of_fire"),
				new RXLZQBreathOfFireItem());
		RXLZQ_MYFAVORITENAME = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "rxlzq_myfavoritename"),
				new RXLZQMyfavoritenameItem());
		ZA_4AR_HELLSING = Registry.register(Registry.ITEM, new ResourceLocation(PuryMusicMod.MODID, "za_4ar_hellsing"), new Za4arHellsingItem());
	}
}
