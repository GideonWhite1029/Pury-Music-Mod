
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.purymusic.init;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

public class PuryMusicModSounds {
	public static SoundEvent AURORA = new SoundEvent(new ResourceLocation("pury_music", "aurora"));
	public static SoundEvent NIGHTWING = new SoundEvent(new ResourceLocation("pury_music", "nightwing"));
	public static SoundEvent BE_A = new SoundEvent(new ResourceLocation("pury_music", "be_a"));
	public static SoundEvent UGLY = new SoundEvent(new ResourceLocation("pury_music", "ugly"));
	public static SoundEvent QWQ = new SoundEvent(new ResourceLocation("pury_music", "qwq"));
	public static SoundEvent VIRTUAL_WORLD = new SoundEvent(new ResourceLocation("pury_music", "virtual_world"));
	public static SoundEvent SHAPE_OF_VOICE = new SoundEvent(new ResourceLocation("pury_music", "shape_of_voice"));
	public static SoundEvent TAKEDA = new SoundEvent(new ResourceLocation("pury_music", "takeda"));
	public static SoundEvent SKINNY_LIFE = new SoundEvent(new ResourceLocation("pury_music", "skinny_life"));
	public static SoundEvent FEAR = new SoundEvent(new ResourceLocation("pury_music", "fear"));
	public static SoundEvent BREATH_OF_FIRE = new SoundEvent(new ResourceLocation("pury_music", "breath_of_fire"));
	public static SoundEvent MY_FAVORITE_NAME = new SoundEvent(new ResourceLocation("pury_music", "my_favorite_name"));
	public static SoundEvent HELLSING = new SoundEvent(new ResourceLocation("pury_music", "hellsing"));
	public static SoundEvent BORN_TO_FLY = new SoundEvent(new ResourceLocation("pury_music", "born_to_fly"));
	public static SoundEvent WOWUTUVEBAANG = new SoundEvent(new ResourceLocation("pury_music", "wowutuvebaang"));

	public static void load() {
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "aurora"), AURORA);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "nightwing"), NIGHTWING);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "be_a"), BE_A);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "ugly"), UGLY);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "qwq"), QWQ);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "virtual_world"), VIRTUAL_WORLD);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "shape_of_voice"), SHAPE_OF_VOICE);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "takeda"), TAKEDA);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "skinny_life"), SKINNY_LIFE);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "fear"), FEAR);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "breath_of_fire"), BREATH_OF_FIRE);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "my_favorite_name"), MY_FAVORITE_NAME);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "hellsing"), HELLSING);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "born_to_fly"), BORN_TO_FLY);
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("pury_music", "wowutuvebaang"), WOWUTUVEBAANG);
	}
}
