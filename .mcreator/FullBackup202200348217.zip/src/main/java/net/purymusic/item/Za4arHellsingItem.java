
package net.purymusic.item;

import net.purymusic.init.PuryMusicModSounds;

import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

public class Za4arHellsingItem extends RecordItem {
	public Za4arHellsingItem() {
		super(0, PuryMusicModSounds.HELLSING, new Item.Properties().tab(CreativeModeTab.TAB_MISC).stacksTo(1).rarity(Rarity.RARE), 100);
	}
}
