
package net.purymusic.item;

import net.purymusic.init.PuryMusicModSounds;

import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

public class MxnarchNightwingItem extends RecordItem {
	public MxnarchNightwingItem() {
		super(0, PuryMusicModSounds.NIGHTWING, new Item.Properties().tab(CreativeModeTab.TAB_MISC).stacksTo(1).rarity(Rarity.RARE), 100);
	}
}
